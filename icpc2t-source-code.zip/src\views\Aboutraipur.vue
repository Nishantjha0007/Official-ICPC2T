<template>
  <div class="col-xl-8 col-md-12">
    <!-- Post -->
    <div class="row mt-2 mb-5 pb-3 mx-2">
      <!-- Card -->
      <div class="card card-body mb-5">
        <h2 class="font-weight-bold mt-3">
          <strong>About Raipur</strong>
        </h2>

        <hr class="red title-hr" />
        <p class="article">
          Raipur is the capital and largest city of the state of Chhattisgarh.
          Raipur is an emerging global hub and has witnessed exponential growth
          over the past years. It contains a diverse population of about a million
          and spans across an area of 180 sq km. It holds 7th position in the Ease
          of Living Index 2018 by Union Ministry of Housing and Urban Affairs.
          <br /><br />
          The city is located near the centre of a large plain, wherein hundreds of
          varieties of rice are grown, by virtue of which Chhattisgarh is the ‘Rice
          bowl of India’. It has The Mahanadi river on its east, Maikal Hills on the
          north-west, Deccan plateau on the south and on the north, land rises and
          merges with the Chota Nagpur Plateau. Archaeological evidence suggest the
          existence of Raipur since the ninth century, whereas literary evidence
          define the history of Raipur since the Mauryan empire. <br /><br />
          Raipur being geographically located at the centre of Chhattisgarh was
          chosen to be its capital on 1st November 2000. The city finds itself 244
          to 409 meters above the sea level. Raipur witnesses tropical wet and dry
          climate, with moderate temperatures most times of the year and blazing hot
          summers. Monsoon brings about 1300 millimeters of rain along.<br /><br />
          The slogan of the city is “Mor Raipur” which means “My Raipur” in
          Chhattisgarhi i.e. the language of Chhattisgarh, which cultivates affinity
          and belongingness towards the city. The city is also developing as a part
          of the Smart Cities initiative. It also holds a strong presence of various
          international brands and prominent global automobile companies.<br /><br />
          Raipur also occurs to be the educational hub of Chattisgarh due to the
          presence of innumerable educational institutions of importance. It is home
          to premier institutes like National Institute of Technology (NIT), All
          India Institute of Medical Sciences (AIIMS), Indian Institute of Management
          (IIM), Hidayatullah National Law University, International Institute of
          Information Technology (IIIT) and National Institute of Malaria Research.
          It also harbours other eminent institutions.<br /><br />
          Raipur garners a plethora of opportunities and a place marching towards
          growth with immense energy and enthusiasm.
        </p>
        <h3><strong>About NIT Raipur </strong></h3>
        <p class="article">
          National Institute of Technology Raipur situated in the capital of a newly
          incepted state of Chhattisgarh, has proven to be “avant-grade’ in the field
          of science and technology over past few decades in this region. With sweet
          memory of foundation ceremony by our Hon’ble President Dr. Rajendra Prasad
          on 14<sup>th</sup> September 1956, the institute started with two departments
          namely Metallurgical and Mining Engineering. Later the inauguration of the
          Institute building was done by our Hon’ble Prime Minister Pt. Jawahar Lal
          Nehru on 14<sup>th</sup> March 1963. From 1<sup>st</sup> December 2005, the
          institute has become the National Institute of Technology. Presently, the
          institute offers 12 undergraduate and 6 postgraduate courses &amp; almost
          Ph.D in all disciplines.
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Aboutraipur",
};
</script>

<style>
.article {
  text-align: justify !important;
  font-family: Ubuntu, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
    "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji",
    "Segoe UI Symbol";
}

h2, h4, p, li {
  font-family: Ubuntu, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
    "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji",
    "Segoe UI Symbol";
}
</style>
