<template>
  <div class="col-xl-8 col-md-12">
    <!-- Post -->
    <div class="row mt-2 mb-5 pb-3 mx-2">
      <!-- Card -->
      <div class="card card-body mb-5">
        <h2 class="font-weight-bold mt-3">
          <strong>Advisory Board Members</strong>
        </h2>
        <hr class="red title-hr" />
        <p class="article">
          <span>Prof. Frede Blaabjerg, Aalborg University, Denmark</span> <br />
          <span>Prof. Kashem Muttaqi, University of Wollongong, Australia</span> <br />
          <span>Prof. Zahra Moravej, Semnan University, Iran</span> <br />
          <span>Prof. Bhim Singh, IIT Delhi</span> <br />
          <span>Prof. Zahra Moravej, Semnan University, Iran</span> <br />
          <span>Prof. Ramesh Bansal, University of Pretoria, South Africa</span> <br />
          <span>Dr. Geetam Tomar, Rajkiya Engg. College, Sonbhadra, UP</span> <br />
          <span>Shri. M K Badapanda, RRCAT, Indore</span> <br />
          <span>Prof. Niranjan Kumar, NIT Jamshedpur</span> <br />
          <span>Prof. Asheesh K Singh, MNNIT Allahabad</span> <br />
          <span>Prof. Almoataz Y. Abdelaziz, Ain Shams University, Egypt</span> <br />
          <span>Prof. Sishaj P Simon, NIT Trichy</span> <br />
        </p>
      </div>
      <!-- entry-content clearfix-->

      <div id="comments" class="comments-area"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Advisory_Committee",
};
</script>
