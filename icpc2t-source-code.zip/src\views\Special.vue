<template>
    <div class="col-xl-8 col-md-12">
      <!-- Post -->
      <div class="row mt-2 mb-5 pb-3 mx-2">
        <!-- Card -->
        <div class="card card-body mb-5">
          <h2 class="font-weight-bold mt-3">
            <strong>Special Session</strong>
          </h2>
          <hr class="red title-hr" />
  
          <div class="article">
            <p class="article">ICPC2T is now accepting papers in the approved special sessions and papers can be submitted on <a
            href="https://cmt3.research.microsoft.com/ICPC2T2025/Submission/Index"
            >paper submission portal</a
          ></p>
          
          <p>SS1: Integration and Control of Renewable Energy with the Power Grid<br><a href="/SS1_brochure.pdf" target="_blank"
            >Download SS1 - Brochure
            <i class="fas fa-file-pdf"></i
          ></a></p>
          <p>SS2: Power Converter Applications in Renewable Energy: New Topologies, Control
            Systems, Condition Monitoring and Energy Efficiency<br><a href="/ss2brochure.pdf" target="_blank"
            >Download SS2 - Brochure
            <i class="fas fa-file-pdf"></i
          ></a></p>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: "Special",
  };
  </script>
  <style scoped>
  li {
    text-align: justify;
  }
  </style>
  