<template>
  <div class="col-xl-8 col-md-12">
    <!-- Post -->
    <div class="row mt-2 mb-5 pb-3 mx-2">
      <!-- Card -->
      <div class="card card-body mb-5">
        <h2 class="font-weight-bold mt-3">
          <strong>Technical Program Committee</strong>
        </h2>
        <hr class="red title-hr" />
        <p class="article">
          <span>Dr. Mohammad Pazoki, Damghan University, Iran</span> <br />
          <span>Dr. Manisha Dubey, MANIT, Bhopal</span> <br />
          <span>Prof. R. K. Nema, MANIT Bhopal</span> <br />
          <span>Dr. S. Nema, MANIT Bhopal</span> <br />
          <span>Prof. V. S. Kale, VNIT Nagpur</span> <br />
          <span>Dr. M. Senthil Kumar, NIT Patna</span> <br />
          <span>Dr. Pradyumn Chaturvedi, VNIT Nagpur</span> <br />
          <span>Dr. A. Kirubakaran, NIT Warangal</span> <br />
          <span>Dr. B. Venugopal Reddy, NIT Warangal</span> <br />
          <span>Dr. Ch. Ramulu, NIT Warangal</span> <br />
          <span>Dr. Shashank Kurm, IIT Bhilai</span> <br />
          <span>Dr. Shailendra Kumar, IIT Bhilai</span> <br />
          <span>Dr. Sateesh Kumar Kuncham, NIT Trichy</span> <br />
          <span>Dr. Kayalvizhi Selvam, NIT Trichy</span> <br />
          <span>Dr. Suresh Lakhimsetty, SVNIT Surat</span> <br />
          <span>Dr. Kunisetti V Praveen Kumar, SVNIT Surat</span> <br />
          <span>Dr. T. Kiran, NIT Andhra</span> <br />
          <span>Dr. Dipanshu Naware, NIT Trichy</span> <br />
          <span>Dr. Hareesh Myneni, NIT Srinagar</span> <br />
          <span>Dr. Hemachander Allamsetty, NIT Puducherry</span> <br />
          <span>Dr. Vishal Anand, REFUdrive, India</span> <br />
          <span>Dr. Manish Barwar, Opal RT, India</span> <br />
          <span>Dr. V. Ashok, National Grid UK Ltd, UK</span> <br />
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Technical_Committee",
};
</script>
