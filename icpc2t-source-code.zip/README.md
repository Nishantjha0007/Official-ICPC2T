Official code for https://icpc2t.nitrr.ac.in/#/
