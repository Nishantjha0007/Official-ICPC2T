<template>
  <div class="col-xl-8 col-md-12">
    <!-- Post -->
    <div class="row mt-2 mb-5 pb-3 mx-2">
      <!-- Card -->
      <div class="card card-body mb-5">
        <h2 class="font-weight-bold mt-3">
          <strong>Our Partners</strong>
        </h2>
        <hr class="red title-hr" />

        <p style="text-align: justify">Site Under Construction</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Partners",
};
</script>
