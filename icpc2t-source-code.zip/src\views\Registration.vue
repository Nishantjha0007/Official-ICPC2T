<template>
  <div class="col-xl-8 col-md-12">
    <!-- Post -->
    <div class="row mt-2 mb-5 pb-3 mx-2">
      <!-- Card -->
                  <div class="card card-body mb-5">
        <h2 class="font-weight-bold mt-3">
          <strong>Registration</strong>
        </h2>
        <hr class="red title-hr" />
                                 <p class="article">
          Author/participants shall pay the registration fee directly to the bank account. The candidate shall send the filled registration form along with the payment proof to <a href="mailto:icpc2t@nitrr.ac.in">icpc2t-2025@nitrr.ac.in</a> on or before
          15/12/2024 and shall fill the registration form by <a href="https://docs.google.com/forms/d/1s9cRpodVDLOAg0AIo19MUmUNwoetBhipJ4dicvYytZg/formrestricted">clicking here</a> . The registration fee details and bank account details are given below.
        </p>
        <h3>Registration Fees (Including GST  *)</h3>

                     <div class="FixedHeightContainer">
          <table class="table-responsive tg">
            <thead>
              <tr>
                <th class="tg-x75h" rowspan="2">
                  <span class="table-head">Category</span><br /><span

                    class="table-head"
                    >(Author)
                  </span>
                </th>
                <th class="tg-x75h" colspan="2">
                  <span class="table-head">IEEE members</span>
                </th>
                <th class="tg-x75h" colspan="2">
                  <span class="table-head">Non-IEEE members</span>
                </th>
              </tr>
              <tr>
                <td class="tg-x75h">
                  <span class="table-head">INR (GST Included )</span>
                </td>
                <td class="tg-x75h">
                  <span class="table-head">USD (GST Included )</span>
                </td>
                <td class="tg-x75h">
                  <span class="table-head">INR (GST Included )</span>
                </td>
                <td class="tg-x75h">
                  <span class="table-head">USD (GST Included )</span>
                </td>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="tg-ltad">
                  <span class="table-head">Student/Research Scholar</span>
                </td>
                <td class="tg-0lax">
                  <span class="table-col">9440/- </span>
                </td>
                <td class="tg-0lax">
                  <span class="table-col">$250</span>
                </td>
                <td class="tg-0lax">
                  <span class="table-col">11,800/-</span>
                </td>
                <td class="tg-0lax">
                  <span class="table-col">$300</span>
                </td>
              </tr>
              <tr>
                <td class="tg-ltad">
                  <span class="table-head">Academician</span>
                </td>
                <td class="tg-0lax">
                  <span class="table-col">11,800/-</span>
                </td>
                <td class="tg-0lax">
                  <span class="table-col">$300</span>
                </td>
                <td class="tg-0lax">
                  <span class="table-col">14,160/-</span>
                </td>
                <td class="tg-0lax">
                  <span class="table-col">$350</span>
                </td>
              </tr>
              <tr>
                <td class="tg-ltad">
                  <span class="table-head">Industry</span>
                </td>
                <td class="tg-0lax">
                  <span class="table-col">14,160/-</span>
                </td>
                <td class="tg-0lax">
                  <span class="table-col">$350</span>
                </td>
                <td class="tg-0lax">
                  <span class="table-col">16,520/-</span>
                </td>
                <td class="tg-0lax">
                  <span class="table-col">$400</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <p>
          <strong class="red-text">
            **The registration fee for foreign participants (outside India) should be paid in USD.
          </strong>
        </p>
        <p class="article">
          <br />
          <strong
            >Good and Service Tax (GST) @ 18% included in the fee</strong
          >
          <br />
          <strong>Participation:</strong>
          <br/>
          
          <span>
          Conference Attendees: INR 5500/USD 200</span>
          <br/>
         
          <strong>Mode of payment</strong>: On line transaction to the account
          of Director -
        </p>
        
       <p class="red-text">
          Account Number: 30042955244, IFSC: SBIN0002852, SBI, Raipur
        </p>  <h4>
            Account details of conference
        </h4>
                     <ul style="list-style-type:none;line-height:1.5"></ul>
        <table class="account_tables">
          <tr><td>Account Name</td><td> Director NIT Raipur </td></tr>
          <tr><td>Account No.</td><td> 30042955244</td></tr>
          <tr><td>IFSC Code</td><td> SBIN0002852</td></tr>
          <tr><td>Swift Code</td><td> SBININBB646</td></tr>
          <tr><td>Bank Name</td><td> State Bank of India</td></tr>
          <tr><td>Branch Name</td><td> NIT Branch</td></tr>
          <tr><td>Address</td><td> G. E. Road, Raipur (C.G.) 492010</td></tr>
          <tr><td>Bank Details</td><td> <a href="/bankdetails.pdf">Click Here</a></td></tr>
        </table> 
                     <br>
                     <h4>
            Publications Opportunities
        </h4> 
        <p class="article">
         <ul>
          <li>
            Based on the recommendations of the reviewer(s) the selected
            full-length articles may be published in SCI/SCIE indexed journals
          </li>
          <li>
            The paper will be published in ieeexplore.com.
          </li>
          <li>
            Publication charges from Publishers end (if any) are to be borne by
            the authors.
          </li> 
        </ul> 
       </p> 
       <p class="article red-text">All the registered and presented papers in the conference will only be submitted to IEEE for their inclusion into IEEE Xplore which Scopus indexed is provided they meet the required IEEE criteria and guidelines.</p>
       
                   <h4>INSTRUCTION TO THE PARTICIPANTS</h4>  
                   <p class="article">
        <ul>
        
<li>The sample paper template is made available on the conference website in Download menu.</li>
<li>The number of pages in the paper should not exceed <strong>six</strong> Papers submitted in the format other than IEEE will not be considered for the conference.</li>
<li>The authors of the accepted papers will be invited for an oral presentation in the conference. All the registered and presented papers in the conference will only be submitted to IEEE for their inclusion into IEEE Xplore which Scopus indexed provided they meet the IEEE guidelines. Further,the registration of at least one author is compulsory for each paper.</li>
<li>The eligible selected papers will be further review for a possible publication in the IEEE Transaction on Industry Applications or IEEE IAS Magazine. </li>
<li style="color: red;"><b>Accomodation will be provided only to the registered students for 19,20 and 21 January.</b></li>
<li>Details of the online and offline mode of presentation will be made available in the ICPC<sup>2</sup>T 2025 conference website in program schedule. </li> 
        </ul>
 </p> 
 
 <h4>CAMERA READY INSTRUCTIONS</h4>
<p class="article red-text"><a href="CAMERAREADY Instruction (2).pdf">Click here for CAMERA READY INSTRUCTIONS</a></p>

 <h4>
  Previous conference proceedings links
</h4> 
            <ul>
<li>ICPC2T <a href="https://ieeexplore.ieee.org/xpl/conhome/9051868/proceeding"> 2020</a></li>
<li>ICPC2T <a href="https://ieeexplore.ieee.org/xpl/conhome/9776593/proceeding"> 2022</a></li>
<li>ICPC2T <a href="https://ieeexplore.ieee.org/xpl/conhome/10474598/proceeding"> 2024</a></li>
</ul> 


             <div class="logo"><img src="@/assets/ieee-xplore-logo.png" alt=""> </div>  
<br> 
<p class="article"> </p>

      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Registration",
};
</script>

<style scoped>
.logo {
  overflow: hidden;
  text-align: center;
}
.tg {
  border-collapse: collapse;
  border-color: #ccc;
  border-spacing: 0;
}
.tg td {
  background-color: #fff;
  border-color: #ccc;
  border-style: solid;
  border-width: 1px;
  color: #333;
  font-family: Arial, sans-serif;
  font-size: 14px;
  overflow: hidden;
  padding: 10px 5px;
  word-break: normal;
}
.tg th {
  background-color: #f0f0f0;
  border-color: #ccc;
  border-style: solid;
  border-width: 1px;
  color: #333;
  font-family: Arial, sans-serif;
  font-size: 14px;
  font-weight: normal;
  overflow: hidden;
  padding: 10px 5px;
  word-break: normal;
}
.tg .tg-x75h {
  font-family: "Times New Roman", Times, serif !important;
  font-size: 18px;
  text-align: center;
  vertical-align: top;
}
.tg .tg-ltad {
  font-size: 14px;
  text-align: left;
  vertical-align: top;
}
.tg .tg-0lax {
  text-align: left;
  vertical-align: top;
}
.table-head {
  font-weight: 700;
  font-style: normal;
  text-decoration: none;
  color: #000;
  background-color: transparent;
}
.table-col {
  font-weight: 400;
  font-style: normal;
  text-decoration: none;
  color: #000;
  background-color: transparent;
}
.account_tables td {
  border: 1px solid rgb(192, 192, 192);
  padding: 8px 10px;
  border-collapse: collapse;
}
</style>
