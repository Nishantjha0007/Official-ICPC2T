<template>
  <div class="col-xl-8 col-md-12">
    <!-- Post -->
    <div class="row mt-2 mb-5 pb-3 mx-2">
      <!-- Card -->
      <div class="card card-body mb-5">
        <h2 class="font-weight-bold mt-3">
          <strong>About India</strong>
        </h2>
        <hr class="red title-hr" />
        <blockquote style="color: #177e89">
          If there is one place on the face of earth where all the dreams of
          living men have found a home from the very earliest days when men
          began the dream of existence it is India.<br /><br />
          <span>~Romain Rolland</span>
        </blockquote>
        <h3>
          MY INDIA IS MY PRIDE
        </h3>
        <p class="article">
          India is one of the oldest civilizations in the world with a
          kaleidoscopic variety and rich cultural heritage, for more than
          <strong>4000 years</strong>. It has reached to a point of all-round
          socio-economic stability during the last <strong>65 years</strong> of
          its Independence. India, a union of states, is a Sovereign, Secular,
          and Democratic Republic with a Parliamentary system of Governance.<br /><br />
          There are <strong>29 states and 7 Union territories</strong> in the
          country. From the largest to the smallest, each State/UT of India is
          unique in it’s - demography, history and culture, dress, festivals,
          language etc.<br /><br />
          The history of nation gives glimpses into the magnanimity of its
          evolution – from a country under British colonialism, to one of the
          leading economies in the world, all within a span of just sixty years.
          More than anything the nationalistic fervour of the people is the
          contributing force behind the culmination of such a development. This
          transformation of the nation instils a sense of national pride in the
          heart of every Indian within country, and this section is a modest
          attempt at keeping its flame alive.<br /><br />
        </p>

        <h3>
          ULTIMATE FACTS OF MY COUNTRY INDIA
        </h3>
        <ul>
          <li>
            The name 'India' is derived from the River Indus, the valleys around
            which were the home of the early settlers. The Aryan worshippers
            referred to the river Indus as the Sindhu.
          </li>
          <li>
            The Persian invaders converted it into Hindu. The name
            <strong>'Hindustan'</strong> combines <strong>Sindhu</strong> and
            Hindu and thus refers to the land of the <strong>Hindus</strong>.
          </li>
          <li>
            The World's First Granite Temple is the
            <strong>Brihadeswara Temple at Tanjavur, Tamil Nadu</strong>. The
            shikhara of the temple is made from a single 80-tonne piece of
            granite. This magnificent temple was built in just five years,
            (‘between 1004 AD and 1009 AD’) during the reign of Rajaraja Chola.
          </li>
          <li>
            The world's first university was established in
            <strong>Takshila in 700 BC</strong>. More than 10,500 students from
            all over the world studied more than 60 subjects. The
            <strong>University of Nalanda</strong> built in the 4th century was
            one of the greatest achievements of ancient India in the field of
            education.
          </li>
          <li>
            Ayurveda is the earliest school of medicine known to mankind. The
            Father of Medicine, Charaka, consolidated Ayurveda 2500 years
            ago.<br /><strong>Sushruta</strong> is regarded as the Father of
            Surgery. Over 2600 years ago Sushruta &amp; his team conducted
            complicated surgeries like cataract, artificial limbs, caesareans,
            fractures, urinary stones, plastic surgery and brain surgeries.<br />Usage
            of anaesthesia was well known in ancient Indian medicine. Detailed
            knowledge of anatomy, embryology, digestion, metabolism, physiology,
            aetiology, genetics and immunity is also found in many ancient
            Indian texts.
          </li>
          <li>
            The value of "π" was first calculated by the Indian Mathematician
            Budhayana. He discovered this in the 6th century, long before the
            European mathematicians.
          </li>
          <li>
            The <strong>Baily Bridge</strong> is the highest bridge in the
            world. It is located in the Ladakh valley between the Dras and Suru
            rivers in the Himalayan Mountains. It was built by the Indian Army
            in August 1982.
          </li>
          <li>
            Yoga has its origins in India and has existed for over 5,000 years.
          </li>
          <li>
            <strong>Mangalyaan, India’s Mars Orbiter</strong>, was made possible
            at the cheapest cost worldwide – and it has celebrated over a 1000
            Earth days in its orbit.
          </li>
          <li>
            More than
            <strong>54 cr. people voted in the 2014 General Election</strong> –
            more people than the population of USA, UK, Australia and Japan
            combined.
          </li>
          <li>
            India has built <strong>ASAT</strong> (“Anti satellite mission
            test”) named as <strong>Shakti</strong> and shown its power and
            control in the space, proudly India is now the fourth country after
            US, Russia, China.
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "AboutIndia",
};
</script>
<style >
h3 {
  border-bottom: 5px solid black;
  padding: 5px 0;
  text-align: center;
}
</style>
