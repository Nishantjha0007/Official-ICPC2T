<template>
  <div class="col-xl-8 col-md-12">
    <!-- Post -->
    <div class="row mt-2 mb-5 pb-3 mx-2">
      <!-- Card -->
      <div class="card card-body mb-5">
        <h2 class="font-weight-bold mt-3">
          <strong>Accomodation</strong>
        </h2>
        <hr class="red title-hr" />

        <p style="text-align: justify">Will be Updated Soon. </p>
       <!-- <br/>
            <li class="list-group-item d-flex">
            <a
              href="https://docs.google.com/spreadsheets/d/1ATfHEAFtUccTHQl7Jtah_h3kHVpycxe__eIM__TW15A/edit?usp=sharing"
              style="color: blue"
            >
             List Of Hotels
            </a>
            </li>
            <br/>
             <p style="font-size:14px">This information is only for your kind support.</p> 
             <p style="font-size:16px"><b>Accomodation will be provided only to the registered students for 19,20 and 21 January.</b></p> 
            <br/>  -->
             <p style="font-size:14px"></p>
             <p style="font-size:16px"><b></b></p> 
        <br/>
      </div>
    <!--  <div class="card card-body mb-5"> 
        
        
        <h4 style="text-align: justify">Help Desk </h4> 
        <hr class="red title-hr" />
        <p>Will be updated soon</p> 
        <p style="text-align: justify">If you have any queries contact to details given below:</p>
        <p class="article"> 
            <span><strong>Mahima Kumari</strong></span> -
            <a href="tel:+919169773063">9169773063</a><span>, </span><a href="kmahima.mahi1997@gmail.com">kmahima.mahi1997@gmail.com</a><br />
            <span><strong>Durgesh Verma</strong></span> -
            <a href="tel:+919827731951">9827731951</a><span>, </span><a href="dverma1901@gmail.com">dverma1901@gmail.com</a><br />
            <span><strong>Nilesh Jagtap</strong></span> -
            <a href="tel:+919067251767">9067251767</a><span>, </span><a href="nhjagtap. phd2021. ee@nitrr.ac.in">nhjagtap. phd2021. ee@nitrr.ac.in</a><br /> -->
        <!-- </p> 
    </div> -->
  </div>
  </div>
</template>

<script>
export default {
  name: "Accomodation",
};
</script>
