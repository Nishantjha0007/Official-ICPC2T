<template>
  <div class="col-xl-8 col-md-12">
    <!-- Post -->
    <div class="row mt-2 mb-5 pb-3 mx-2">
      <!-- Card -->
      <div class="card card-body mb-5">
        <h2 class="font-weight-bold mt-3">
          <strong>Downloads</strong>
        </h2>
        <hr class="red title-hr" />
        <ul class="list-group z-depth-1 mt-4">
          <li class="list-group-item d-flex">
            <a href="/brochure.pdf" class="red-text" target="_blank">
              • Download ICPC<sup>2</sup>T 2025 - Brochure
              <i class="fas fa-file-pdf"> </i
            ></a>
          </li>
          <li class="list-group-item d-flex">
            <a
              href="ICPC2T-2025_format.pptx"
              style="color: blue"
            >
              • Click here to download ppt format.
            </a>
            <a
              href="https://www.ieee.org/conferences/publishing/templates.html"
              style="color: blue"
            >
              • Click here to download different templates of IEEE conference
              papers.
            </a>
          </li>
          <li
            class="list-group-item d-flex list-group-flush"
            style="color: blue"
          >
            • Templates of IEEE conference papers.
            <ul>
              <li class="list-group-item d-flex">
                <a href="/conference-template-a4.docx" style="color: blue"
                  >1. Microsoft Word - US letter</a
                >
              </li>
              <li class="list-group-item d-flex">
                <a href="/conference-template-letter.docx" style="color: blue">
                  2. Microsoft Word - A4</a
                >
              </li>
            </ul>
          </li>
          <!-- <li class="list-group-item d-flex">
            <a
              href="/ICPC2T-2024.pptx"
              style="color: blue"
            >
              • Download sample PPT template.
            </a>
          </li> -->
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Downloads",
};
</script>
