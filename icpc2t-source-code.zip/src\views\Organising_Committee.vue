<template>
  <div class="col-xl-8 col-md-12">
    <!-- Post -->
    <div class="row mt-2 mb-5 pb-3 mx-2">
      <!-- Card -->
      <div class="card card-body mb-5">
        <h2 class="font-weight-bold mt-3">
          <strong>Organizing Committee</strong>
        </h2>
        <hr class="red title-hr" />
        <div class="content">
          <p class="article">
            <br /><span class="heading">Chief Patron(s)</span><br />
            <span>Dr. N. V. Ramana Rao, Director, NIT Raipur</span><br />
            <br /><span class="heading">Patron(s)</span><br />
            <span>Prof. Dr. Guru Prasad Subas Chandra Mishra, Dean (R&C), NIT Raipur</span><br />
            <span>Prof. Shubhrata Gupta , Dean (Academics), NIT Raipur</span><br />
                         <br /><span class="heading">Honorary Chair</span><br />
            <span> Prof. Frede Blaabjerg, Villum Investigator, Aalborg University, Denmark</span><br />
            <span>Prof. Kashem Muttaqi, University of Wollongong, Australia</span><br />
            <span>Prof. Prof. Kleber Melo e Silva, University of Brasilia, Brazil</span><br />
            <span>Prof. Zahra Moravej, Semnan University, Iran</span><br />
            <span>Prof. Bhim Singh, SERB National Science Chair & Emeritus Professor, IIT-Delhi</span><br />
            <span>Prof. Nilesh J. Vasa, IIT Madras</span><br />
           <!--<span> Prof. Akshay Kumar Rathore, Singapor Institute of Technology</span><br />
            <span> Prof. Biplab Sikdar, National University of Singapore, Singapore </span><br />
            <span> Prof. Vinod Khadkikar, Khalifa University, UAE </span><br /> -->
            <br /><span class="heading">General Chairs</span><br />
            <span
              >Dr. Anamika Yadav,  Dept. of Electrical Engineering, NIT
              Raipur</span
            ><br />
            <br /><span class="heading"
              >Coordinators/ Organizing Secretaries</span
            ><br />
            <span>Dr. Varsha Singh, NIT Raipur</span><br />
            <span>Dr. Venu Sonti, NIT Raipur</span><br />
            <span>Dr. Haripriya Vemuganti, NIT Raipur</span><br />
            <span>Dr. Ramya Selvaraj, NIT Raipur</span><br />
            <br /><span class="heading">Publication Chairs</span><br />
            <span>Dr. S. Gupta, NIT Raipur </span><br />
            <span>Dr. P. D. Dewangan, NIT Raipur</span><br />
            <span>Dr. S. Ghosh, NIT Raipur</span><br />
            <span>Dr. R.N. Patel, CSVTU, Bhilai</span><br />
            <span>Prof. Sachin Jain, NIT Raipur</span><br />
            <span>Dr. Monalisa Biswal, NIT Raipur</span><br />
            <span>Dr. Chilaka Ranga, VNIT Nagpur</span><br />
            <br /><span class="heading">Publicity Chairs</span><br />
            <span>Dr. Narendra D. Londhe, NIT Raipur</span><br />
            <span>Dr. Ritesh Keshri, VNIT Nagpur</span><br />
            <span>Dr. Swapnajit Patnaik, NIT Raipur
            </span><br />
            <span>Dr. D. Suresh, NIT Raipur</span><br />
            <span>Dr. Rajan Kumar ,NIT Raipur </span><br/>
            <br /><span class="heading">Finance Chair</span><br />
            <span>Dr. B. Shaw, NIT Raipur</span><br />
            <span>Dr. Ebha Koley, NIT Raipur</span><br />
            <span>Dr. Baidyanath Bag, NIT Raipur</span><br />
            <span>Dr. Surajit Sannigrahi, NIT Raipur</span><br />
                       <!--  <br /><span class="heading">Track Chair(Tentative)</span><br />
            <span>Dr. Satish Belkhode, IIT Roorkee</span><br />
            <span>Dr. Anuj Soni, BARC</span><br />
            <span>Dr. Sunita Ahlawat, RRCAT</span><br />
            <span>Dr. Pranab Kumar Mukhopadhyay, RRCAT</span><br />
            <span>Dr. Ramsha Karampuri, VNIT Nagpur</span><br />
            <span>Dr. K. Chandrasekaran, NIT Raipur</span><br />
            <span>Dr. Rajan Kumar, NIT Raipur</span><br /> -->
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Organising_Committee",
};
</script>
<style scoped>
.heading {
  color: #006699;
  font-size: 16px;
  font-weight: bold;
  text-decoration: underline;
  padding-bottom: 5px;
}
</style>
