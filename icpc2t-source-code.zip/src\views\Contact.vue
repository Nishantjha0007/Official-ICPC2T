<template>
  <div class="col-xl-8 col-md-12">
    <!-- Post -->
    <div class="row mt-2 mb-5 pb-3 mx-2">
      <!-- Card -->
      <div class="card card-body mb-5">
        <h2 class="font-weight-bold mt-3">
          <strong>Contact Us</strong>
        </h2>
        <hr class="red title-hr" />

        <div class="entry-content" itemprop="text">
          <p class="article">
            <span style=""
              >Please contact for further details and clarifications:</span
            >
          </p>
          <p class="article">
            <span><strong>Dr. Varsha Singh </strong></span> -
            <a href="tel:+919441700975">9425524731</a><br />
            <span><strong>Dr. Haripriya Vemuganti </strong></span> -
            <a href="tel:+919301199854">9948226112</a><br />
            <span><strong>Dr. Venu Sonti </strong></span> -
            <a href="tel:+919827215396">9618832222</a><br />
            <span><strong>Dr. Ramya Selvaraj</strong></span> -
            <a href="tel:+919441700975">8754465755</a><br />
            <span
              >E-mail:
              <a href="mailto: icpc2t@nitrr.ac.in"
                > icpc2t@nitrr.ac.in</a
              ></span
            ><br />
            <span>ICPC<sup>2</sup>T 2026,</span><br />
            <span
              >National Institute of Technology Raipur – 492010, Chhattisgarh,
              India.</span
            >

            <span><br /> </span>
          </p>
        </div>
        <!-- entry-content clearfix-->

        <div id="comments" class="comments-area"></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Contact",
};
</script>
<style scoped>
span {
  font-size: 12pt;
}
</style>
