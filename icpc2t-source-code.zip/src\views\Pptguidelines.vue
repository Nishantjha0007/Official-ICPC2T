<template>
  <div class="col-xl-8 col-md-12">
    <!-- Post -->
    <div class="row mt-2 mb-5 pb-3 mx-2">
      <!-- Card -->
      <div class="card card-body mb-5">
        <h2 class="font-weight-bold mt-3">
            <strong>PPT GUIDELINES</strong>
        </h2>
        <hr class="red title-hr" />
<p class="article">You are requested to prepare your presentation using sample PPT as given in link <a href="ICPC2T-2025_format.pptx">click here</a>. It is author’s responsibility presenting in on-line mode to have good internet connection so that they can present their presentation by screen sharing via zoom meeting link though we are taking audible PPT. Authors should be present in online mode during the presentation and should present in on-line mode then only their paper may be considered. The PPT must highlight your main contribution made, along with brief background of previous work, as the time limit is restricted to 10 Minutes only. 
</p> 
</div>
</div>
</div>
</template>
<script>
export default {
  name: "Pptguidelines",
};
</script>