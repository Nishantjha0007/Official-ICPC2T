<template>
  <div class="col-xl-8 col-md-12">
    <!-- Post -->
    <div class="row mt-2 mb-5 pb-3 mx-2">
      <!-- Card -->
      <div class="card card-body mb-5">
        <h2 class="font-weight-bold mt-3">
          <strong>Workshop</strong>
        </h2>
        <hr class="red title-hr" />

        <!-- <carousel id="primary"
      :per-page="1"
      :mouse-drag="false"
      :autoplay=true
      :speed=2000
      :loop=true
      :autoplayHoverPause=true
    >
      <slide
        data-index="0"
        data-name="MySlideName"
      
        :centerMode="true"
      >
        <img class="carousel-img" src="@/assets/Workshop1.jpg" />
      </slide>
      <slide
        data-index="1"
        data-name="MySlideName"
      
        :centerMode="true"
      >
        <img class="carousel-img" src="@/assets/workshop3.jpeg" />
      </slide>
      <slide
        data-index="2"
        data-name="MySlideName"
      
        :centerMode="true"
      >
        <img class="carousel-img" src="@/assets/Workshop2.jpeg" />
      </slide>
      
    </carousel> -->
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Workshops",
  components: {},
};
</script>

<style scoped>
.carousel-img {
  height: 800px;
  width: 100%;
}
</style>
