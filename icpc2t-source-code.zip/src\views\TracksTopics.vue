<template>
  <div class="col-xl-8 col-md-12">
    <!-- Post -->
    <div class="row mt-2 mb-5 pb-3 mx-2">
      <!-- Card -->
      <div class="card card-body mb-5">
        <h2 class="font-weight-bold mt-3">
          <strong>Conference Tracks/Topics</strong>
        </h2>
        <hr class="red title-hr" />
        <p>
          Papers are invited in the following areas of interest, but not limited
          to:
        </p>
        <ul>
          <li>Power Systems</li>
          <li>Power Quality</li>
          <li>Green Technology</li>
          <li>Renewable Energy</li>
          <li>Smart Grid</li>
          <li>Cyber Security for electrical systems</li>
          <li>High Voltage Technologies</li>
          <li>HVDC and FACTS Devices</li>
          <li>Power Electronics and Drives</li>
          <li>Electric Transportation Systems</li>
          <li>Instrumentation and Control</li>
          <li>Process Control and Automation</li>
          <li>Signal and Image Processing Techniques</li>
          <li>Cyber Physical Systems for electrical systems</li>
          <li>Internet of Things</li>
          <li>Data Mining</li>
          <li>Cloud Computing</li>
          <li>Data Analytics</li>
          <li>
            Artificial Intelligence and Machine Learning for electrical systems
          </li>
          <li>Optimization Techniques for electrical systems</li>
          <li>Deep Learning for electrical systems</li>
          <li>Control Engineering</li>
        </ul>
      </div>
    </div>
    <!-- #main -->
  </div>
</template>

<script>
export default {
  name: "TracksTopics",
};
</script>
<style scoped>
li {
  text-align: justify;
}
</style>
